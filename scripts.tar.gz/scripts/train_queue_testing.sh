#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-http://127.0.0.1:8000}"
CITY_ID="${CITY_ID:-3}"
ADMIN_KEY="${ADMIN_KEY:-Mathew-evony-admin-9f3c7d2a11}"

# How long training should take (short for tests)
TRAIN_SECONDS="${TRAIN_SECONDS:-3}"

# If your endpoint uses a different field name, change this:
SECONDS_FIELD="${SECONDS_FIELD:-seconds}"

die() { echo "❌ $*" >&2; exit 1; }

echo "== Login Alicia =="
TOKEN=$(
  curl -sS -X POST "$BASE/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"username":"alicia","password":"ChangeMe123!"}' | jq -r .token
)
[ -n "${TOKEN:-}" ] && [ "$TOKEN" != "null" ] || die "Login failed (token empty/null)"

echo "== Confirm training queue route exists =="
HAS_ROUTE=$(curl -sS "$BASE/openapi.json" | jq -r --arg p "/cities/{city_id}/train/queue" '.paths | has($p)')
[ "$HAS_ROUTE" = "true" ] || die "Missing route: POST /cities/{city_id}/train/queue (restart server or add endpoint)"

echo "== Read t1_inf count before =="
before="$(
  curl -sS -H "Authorization: Bearer $TOKEN" \
    "$BASE/cities/$CITY_ID/troops" \
    | jq -r '.troops[] | select(.code=="t1_inf") | .count' | head -n1
)"
before="${before:-0}"
echo "before=$before"

echo "== Queue training (finishes in ~${TRAIN_SECONDS}s) =="
BODYFILE=$(mktemp)
STATUS=$(
  curl -sS -o "$BODYFILE" -w "%{http_code}" \
    -X POST "$BASE/cities/$CITY_ID/train/queue" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"troops\":[{\"code\":\"t1_inf\",\"count\":10}],\"${SECONDS_FIELD}\":${TRAIN_SECONDS}}"
)
BODY=$(cat "$BODYFILE"); rm -f "$BODYFILE"

if [ "$STATUS" != "200" ]; then
  echo "Queue failed (status=$STATUS):"
  echo "$BODY" | jq . 2>/dev/null || echo "$BODY"
  die "Queue training failed"
fi
echo "$BODY" | jq .
echo "✅ queued"

echo "== Immediately verify troops unchanged (still $before) =="
now1="$(
  curl -sS -H "Authorization: Bearer $TOKEN" \
    "$BASE/cities/$CITY_ID/troops" \
    | jq -r '.troops[] | select(.code=="t1_inf") | .count' | head -n1
)"
now1="${now1:-0}"
echo "immediate=$now1"
[ "$now1" = "$before" ] || die "Expected no immediate troop change; before=$before immediate=$now1"

echo "== Wait for completion (${TRAIN_SECONDS}s + buffer) =="
sleep $((TRAIN_SECONDS + 1))

echo "== Trigger tick on read (/cities/{id} calls tick_world_now) =="
curl -sS -H "Authorization: Bearer $TOKEN" "$BASE/cities/$CITY_ID" >/dev/null

echo "== Verify troops increased by 10 =="
after="$(
  curl -sS -H "Authorization: Bearer $TOKEN" \
    "$BASE/cities/$CITY_ID/troops" \
    | jq -r '.troops[] | select(.code=="t1_inf") | .count' | head -n1
)"
after="${after:-0}"
echo "after=$after"

expected=$((before + 10))
[ "$after" -eq "$expected" ] || die "Expected after=$expected but got after=$after"

echo "✅ Training queue UI-test passed"

